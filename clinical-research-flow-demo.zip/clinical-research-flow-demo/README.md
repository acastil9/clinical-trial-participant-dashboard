# Clinical Research Flow — Interactive Demonstration

An independent, browser-based educational prototype that visualizes a fictional clinical research participation journey, from preliminary screening and laboratory review to eligibility, follow-up visits, and enrollment.

## Live demo

To publish with GitHub Pages, open your repository **Settings → Pages → Deploy from a branch**, select the `main` branch and `/ (root)` folder. The site will use `index.html`.

## Features

- Responsive dashboard for iPad, desktop, and mobile browsers
- Conversion funnel and participant status summary
- Filters for fictional study and site codes
- Fictional records that can be viewed and edited in the current browser session
- Hypothetical follow-up timing and non-return reason analysis
- CSV export of demo records
- No packages, backend, login, or database required

## Running locally

Open `index.html` in any modern browser, or host the repository through GitHub Pages.

## Important limitations

- **All sample data are synthetic.** Do not enter actual patient records, identifiers, clinical outcomes, or regulated data.
- In-page changes do **not** persist after refresh; export is demonstration-only.
- This is **not** a HIPAA-compliant, validated, or production-ready clinical trial management system.
- Follow-up metrics use an arbitrary **28-day example rule** for visualization. They are not protocol recommendations.
- Figures are illustrative, not empirical results or performance benchmarks.
- This is an **independent educational portfolio project**, not sponsored by, connected to, or endorsed by any clinical research organization or software vendor.

## Technologies

HTML, CSS, vanilla JavaScript. Zero external dependencies.

## Ideas for future development

Validated cohort definitions, user-configurable follow-up windows, aggregate-only reporting, accessibility checks, and approved read-only integration with clinical research platforms (subject to organization authorization and applicable privacy and quality requirements).
